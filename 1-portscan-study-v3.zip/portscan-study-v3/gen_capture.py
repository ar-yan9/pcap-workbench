#!/usr/bin/env python3
"""Seeded classic-PCAP generator with labeled ground truth for evaluation.
Scenarios:
  NORMAL   office web traffic (80/443 handshakes, DNS queries)
  FAST     fast SYN scan: 1 source -> 50 distinct ports on 1 target in ~20 s
  SLOW     slow SYN scan: 12 distinct ports, one every 10 s (110 s span)
  DIST     distributed scan: 10 sources x 5 ports each on 1 target
  UDPSCAN  UDP probes to 20 distinct ports (no SYN flag at all)
  V6FAST   fast SYN scan over IPv6: 1 source -> 25 distinct ports in ~10 s
  ADMIN    benign admin health-check: 12 distinct ports in 30 s (not an attack)
  RETRY    benign retransmissions: 25 SYN retries to the SAME port
Everything is synthetic; documentation addresses only (RFC 5737 / RFC 3849).
"""
import struct, random, sys
from pathlib import Path

random.seed(20261027)
BASE_NS = 1_774_300_000_000_000_000  # fixed epoch-ish, reproducible
pkts = []   # (time_ns, ethernet_frame_bytes, label)

def csum(data):
    if len(data) % 2: data += b'\x00'
    s = sum(struct.unpack('!%dH' % (len(data)//2), data))
    s = (s >> 16) + (s & 0xffff); s += s >> 16
    return (~s) & 0xffff

def ipv4(src, dst, proto, payload):
    hdr = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20+len(payload), 0, 0, 64, proto, 0, src, dst)
    chk = csum(hdr)
    return struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20+len(payload), 0, 0, 64, proto, chk, src, dst) + payload

def ipv6(src, dst, nxt, payload):
    return struct.pack('!IHBB16s16s', 0x60000000, len(payload), nxt, 64, src, dst) + payload

def tcp(sport, dport, syn=True, ack=False, seq=0, payload=b''):
    flags = (0x02 if syn else 0) | (0x10 if ack else 0)
    hdr = struct.pack('!HHLLBBHHH', sport, dport, seq, 0, 0x50, flags, 65535, 0, 0)
    return hdr + payload

def udp(sport, dport, payload=b'x'):
    return struct.pack('!HHHH', sport, dport, 8+len(payload), 0) + payload

def dns_query(name):
    tid = 0x1234; flags = 0x0100
    q = struct.pack('!HHHHHH', tid, flags, 1, 0, 0, 0)
    for part in name.split('.'):
        q += bytes([len(part)]) + part.encode()
    return q + b'\x00' + struct.pack('!HH', 1, 1)

def eth(payload, kind):
    return b'\xaa\xbb\xcc\xdd\xee\xff' + b'\x11\x22\x33\x44\x55\x66' + struct.pack('!H', kind) + payload

def transport_checksum(src, dst, proto, payload, v6):
    offset = 16 if proto == 6 else 6
    payload = payload[:offset] + b'\0\0' + payload[offset+2:]
    pseudo = src + dst + (struct.pack('!I3xB', len(payload), proto) if v6 else struct.pack('!BBH', 0, proto, len(payload)))
    check = csum(pseudo + payload) or 0xffff
    return payload[:offset] + struct.pack('!H', check) + payload[offset+2:]

def add_v4(t_ns, src, dst, proto, payload, label):
    payload = transport_checksum(src, dst, proto, payload, False)
    frame = eth(ipv4(src, dst, proto, payload), 0x0800)
    pkts.append((t_ns, frame, label))

def add_v6(t_ns, src, dst, nxt, payload, label):
    payload = transport_checksum(src, dst, nxt, payload, True)
    frame = eth(ipv6(src, dst, nxt, payload), 0x86dd)
    pkts.append((t_ns, frame, label))

def ip4(a,b,c,d): return bytes([a,b,c,d])

T = 0
def t(sec): return BASE_NS + int(sec*1e9)

# ---- NORMAL: 40 clients, web browsing + DNS over a day slice (~2 hours) ----
clients = [ip4(203,0,113,random.randint(10,60)) for _ in range(40)]
websites = ['example%d.test' % i for i in range(15)]
for sec in range(0, 7200, 37):
    c = random.choice(clients)
    srv = ip4(198,51,100,random.choice([80,90,100]))
    add_v4(t(sec), c, srv, 17, udp(random.randint(40000,60000), 53, dns_query(random.choice(websites))), 'NORMAL')
    sp = random.randint(40000,60000)
    dp = random.choice([80,443])
    add_v4(t(sec+0.1), c, srv, 6, tcp(sp, dp), 'NORMAL')
    add_v4(t(sec+0.2), srv, c, 6, tcp(dp, sp, syn=True, ack=True), 'NORMAL')
    add_v4(t(sec+0.3), c, srv, 6, tcp(sp, dp, syn=False, ack=True, seq=1), 'NORMAL')

# ---- FAST scan: 192.0.2.66 -> 198.51.100.20, 50 ports in ~20 s ----
t0 = 8000
for i in range(50):
    add_v4(t(t0 + i*0.4), ip4(192,0,2,66), ip4(198,51,100,20), 6, tcp(44444, 20+i), 'FAST')

# ---- SLOW scan: 192.0.2.77 -> 198.51.100.20, 12 ports, 10 s apart ----
t0 = 9000
for i in range(12):
    add_v4(t(t0 + i*10), ip4(192,0,2,77), ip4(198,51,100,20), 6, tcp(55555, 300+i), 'SLOW')

# ---- DIST scan: 10 sources x 5 ports on 198.51.100.30 ----
t0 = 10000
for s in range(10):
    for p in range(5):
        add_v4(t(t0 + s*2 + p*0.3), ip4(192,0,2,100+s), ip4(198,51,100,30), 6, tcp(40000+s, 500+p), 'DIST')

# ---- UDP scan: 192.0.2.88 -> 20 distinct UDP ports ----
t0 = 11000
for i in range(20):
    add_v4(t(t0 + i*0.5), ip4(192,0,2,88), ip4(198,51,100,40), 17, udp(45678, 1000+i), 'UDPSCAN')

# ---- V6FAST scan over IPv6: 25 ports in ~10 s ----
v6src = bytes.fromhex('20010db8000000000000000000000001')
v6dst = bytes.fromhex('20010db8000000000000000000000002')
t0 = 12000
for i in range(25):
    add_v6(t(t0 + i*0.4), v6src, v6dst, 6, tcp(46666, 2000+i), 'V6FAST')

# ---- ADMIN benign: monitoring host checks 12 ports in 30 s ----
t0 = 13000
for i in range(12):
    add_v4(t(t0 + i*2.5), ip4(203,0,113,5), ip4(198,51,100,50), 6, tcp(38000, 7000+i), 'ADMIN')
    add_v4(t(t0 + i*2.5 + 0.1), ip4(198,51,100,50), ip4(203,0,113,5), 6, tcp(7000+i, 38000, syn=True, ack=True), 'ADMIN')

# ---- RETRY benign: 25 SYN retransmissions to the SAME port 22 ----
t0 = 14000
for i in range(25):
    add_v4(t(t0 + i*2), ip4(203,0,113,9), ip4(198,51,100,60), 6, tcp(39000, 22), 'RETRY')

pkts.sort(key=lambda x: x[0])
out, lab = sys.argv[1], sys.argv[2]
with open(out, 'wb') as f:
    f.write(struct.pack('<IHHIIII', 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))
    n = 0
    with open(lab, 'w') as g:
        for tns, frame, label in pkts:
            n += 1
            sec = tns // 1_000_000_000
            usec = (tns % 1_000_000_000) // 1000
            f.write(struct.pack('<IIII', sec, usec, len(frame), len(frame)))
            f.write(frame)
            g.write(f'{n}\t{label}\n')
# Explicit finite evaluation episodes. NORMAL is one background control unit,
# not an estimate of the number of real-world negative opportunities.
import json
units = []
for name in ['NORMAL','FAST','SLOW','DIST','UDPSCAN','V6FAST','ADMIN','RETRY']:
    rows = [(i+1, x) for i,x in enumerate(pkts) if x[2] == name]
    units.append(dict(id=name, attack=name in {'FAST','SLOW','DIST','UDPSCAN','V6FAST'},
                      packet_numbers=[i for i,_ in rows],
                      start_ns=min(x[0] for _,x in rows), end_ns=max(x[0] for _,x in rows)))
Path(lab + '.events.json').write_text(json.dumps(units, indent=2) + '\n')
print(f'packets={n}')
