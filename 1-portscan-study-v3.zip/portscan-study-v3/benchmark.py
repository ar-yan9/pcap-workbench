#!/usr/bin/env python3
"""Linux CLI runtime and child peak RSS, 10 measured runs after one warmup/size."""
import argparse, json, os, platform, random, statistics, struct, subprocess, sys, tempfile, time, resource
from pathlib import Path

def generate(path,n):
    rng=random.Random(11)
    with open(path,'wb') as f:
        f.write(struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1))
        for i in range(n):
            src=bytes([203,0,113,rng.randint(2,254)]); dst=bytes([198,51,100,rng.randint(2,254)])
            tcp=struct.pack('!HHLLBBHHH',rng.randint(40000,60000),rng.choice([80,443,22,8080]),0,0,0x50,0x10,65535,0,0)
            ip=struct.pack('!BBHHHBBH4s4s',0x45,0,40,0,0,64,6,0,src,dst)
            frame=bytes.fromhex('aabbccddeeff1122334455660800')+ip+tcp
            f.write(struct.pack('<IIII',1774300000+i//100,i%100*10000,54,54)+frame)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('implementation');ap.add_argument('--repeats',type=int,default=10);a=ap.parse_args()
    out=dict(python=sys.version,platform=platform.platform(),cpu_count=os.cpu_count(),method='Linux wait4 child peak RSS; perf_counter full CLI + JSON serialization; one warmup, then sequential runs; no cache flush; synthetic ACK-only many-flow workload',results=[])
    with tempfile.TemporaryDirectory() as d:
        for n in [10000,25000,50000,100000]:
            path=Path(d)/'bench.pcap';generate(path,n); samples=[]
            for r in range(a.repeats+1):
                t=time.perf_counter()
                # Redirect output to a file to avoid pipe deadlock while wait4 waits.
                with open(Path(d)/'report.json','w') as stdout, open(Path(d)/'stderr','w') as stderr:
                    proc=subprocess.Popen([sys.executable,a.implementation,str(path),'--format','json'],stdout=stdout,stderr=stderr)
                    _,status,usage=os.wait4(proc.pid,0)
                    proc.returncode=os.waitstatus_to_exitcode(status)
                elapsed=time.perf_counter()-t
                if proc.returncode!=0: raise RuntimeError((Path(d)/'stderr').read_text())
                rep=json.loads((Path(d)/'report.json').read_text());assert rep['stats']['capture_records']==n
                if r: samples.append(dict(seconds=elapsed,peak_rss_kib=usage.ru_maxrss))
            ts=[s['seconds'] for s in samples]; mem=[s['peak_rss_kib'] for s in samples]
            out['results'].append(dict(records=n,file_bytes=path.stat().st_size,samples=samples,median_seconds=statistics.median(ts),min_seconds=min(ts),max_seconds=max(ts),sample_stdev_seconds=statistics.stdev(ts),median_peak_rss_mib=statistics.median(mem)/1024,max_peak_rss_mib=max(mem)/1024,median_packets_per_second=n/statistics.median(ts)))
        generate(path,150000)
        proc=subprocess.run([sys.executable,a.implementation,str(path),'--format','json'],capture_output=True,text=True)
        rep=json.loads(proc.stdout);out['cap_check']=dict(input_records=150000,analyzed_records=rep['stats']['capture_records'],exit_code=proc.returncode,notices=rep['notices'])
    print(json.dumps(out,indent=2))
