#!/usr/bin/env python3
"""Reproduce fixture hashes and deterministic metric outputs in a clean temp dir."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from evaluate import evaluate
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as d:
    p=Path(d)/'eval.pcap';l=Path(d)/'eval.labels'
    subprocess.run([sys.executable,str(root/'gen_capture.py'),str(p),str(l)],check=True)
    for new,old in [(p,root/'data/eval.pcap'),(l,root/'data/eval.labels'),(Path(str(l)+'.events.json'),root/'data/eval.labels.events.json')]:
        assert new.read_bytes()==old.read_bytes(),str(old)
    actual=evaluate(str(root/'evaluated_workbench.py'),str(p),str(l))
    assert actual==json.loads((root/'results/evaluation.json').read_text())
    for name,digest in json.loads((root/'sha256.json').read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('PASS: regenerated PCAP, packet labels, event manifest, eight strict metric rows and all manifest hashes')
