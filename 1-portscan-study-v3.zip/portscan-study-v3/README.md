# Port-scan study: reproducibility artifacts (revision 3)

For "Sliding-Window Detection of TCP Port-Scanning Patterns in Offline Network Captures: Design and Evaluation". All captures are synthetic; this is not real-world validation. No network probes are sent.

## Provenance
Evaluated implementation: https://github.com/ar-yan9/pcap-workbench/commit/063ad1d4d75de970fbf84c7c5d5f46ef9709e36f
`evaluated_workbench.py` is a byte-identical frozen copy of that commit's workbench.py, not a modified detector. Results are from this frozen copy. Use `git show 063ad1d4d75de970fbf84c7c5d5f46ef9709e36f:workbench.py` to check it. Publication of these artifacts does not publish or submit the manuscript.

## Run from this folder
Python 3.10+; no third-party Python packages. Evaluation works cross-platform; RSS benchmark requires Linux (`os.wait4`, KiB ru_maxrss).

```
python3 gen_capture.py data/eval.pcap data/eval.labels
python3 evaluate.py evaluated_workbench.py data/eval.pcap data/eval.labels > evaluation.local.json
python3 -m unittest -v test_evaluation
python3 verify.py
python3 benchmark.py evaluated_workbench.py > benchmark.local.json
```

Run original implementation tests from repository root with `python3 -m unittest -v`. The older private README incorrectly used `discover -s tests`; there is no tests/ directory.

The generator overwrites its requested outputs. Run it in a disposable working copy. `verify.py` regenerates into a temporary directory and compares bytes, all eight metric rows, and SHA-256 manifest. Timing and RSS depend on environment and are not expected to be bit-identical. Raw individual measurements and environment are in results/benchmark.json.

## Fixture revision
Seed 20261027; 986 records. Unlike the older private fixture, generated TCP/UDP checksums are valid and background handshake tuples use the same server port. The ACK sequence fields are simplified, so this is still not a realistic application session or a baseline-comparison-ready workload. Original scenario definitions and detector outcomes are unchanged, but the exact background flow count changed. The checked-in PCAP and packet labels plus event manifest define the new evaluated input. The benchmark uses seed 11 and synthetic ACK-only flows; it is a throughput fixture, not a protocol-valid IDS benchmark (transport/IP checksums are placeholders there).

## Strict matching and metric units
Eight fixed evaluation units: five attack episodes (FAST, SLOW, DIST, UDPSCAN, V6FAST), two benign episodes (ADMIN, RETRY), and one NORMAL background-control unit. DIST means the whole coordinated campaign, not ten independent attacks. NORMAL's many packets count as one control, not hundreds of true negatives.

An alert can match exactly one unit, only once, if every evidence packet belongs to that unit; evidence is nonempty and unique; every packet decodes to TCP SYN without ACK; all evidence has one source-target pair; distinct ports meet the configured threshold; and evidence time span fits the inclusive window. Pure benign alerts are false positives. Mixed, invalid and repeated alerts are unmatched and count as additional alert false positives. Greedy matching follows detector alert order; units are disjoint, so candidate assignment is unambiguous. This replaces the old any-one-packet hit criterion, without changing detection logic.

Alert precision = matched attack alerts / all emitted alerts. Event recall = matched attack units / five attack units. The event confusion matrix has TP/FN over the five attack units and FP/TN over the three benign/control units. Unmatched/duplicate alerts are listed separately because an event confusion matrix cannot represent arbitrary duplicate alert counts. TN is not defined for an alert-only confusion matrix. No population accuracy, production FPR or statistical confidence claim is made.

Default: TP=2, FN=3, FP=1, TN=2; precision=2/3; recall=2/5. At threshold five, DIST emits ten source-pair alerts, of which only one receives campaign credit; nine are penalized as duplicate alerts. Thus TP=4, FN=1, FP=1, TN=2 but alert precision=4/14. There is no score inflation from ten alerts for one event. The event recall figure still permits early partial-episode detection, as operational alerting does; evidence coverage and delay are included in outputs, not hidden.

## Benchmark scope
Sizes 10k/25k/50k/100k, one warmup then ten sequential full CLI runs each, including JSON serialization to file; no cache flush. Wall time uses perf_counter; child peak RSS uses Linux wait4, not cumulative RUSAGE_CHILDREN. Reports median/min/max/sample SD, per-run RSS and throughput. A separate 150k-input cap check confirms only 100k records are analyzed with exit 2 and a limit notice. No claim of complete large-file processing. Capture generation is outside timing; machine is shared and results are workload-specific, not a competitive benchmark. No Snort/Zeek run was performed.
