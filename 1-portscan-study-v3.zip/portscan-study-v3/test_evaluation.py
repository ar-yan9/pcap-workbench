import unittest
from evaluate import match
class StrictMatching(unittest.TestCase):
    def setUp(self):
        self.d={i:dict(protocol='TCP',syn=True,ack=False,src='a',dst='b',dport=i,time_ns=i*10**9) for i in range(1,5)}
        self.u=[dict(id='A',attack=True,packet_numbers=[1,2],start_ns=10**9,end_ns=2*10**9),dict(id='B',attack=False,packet_numbers=[3,4],start_ns=3*10**9,end_ns=4*10**9)]
    def score(self,nums): return match([dict(evidence_packets=n) for n in nums],self.u,self.d,60,2)
    def test_pure(self): self.assertEqual(self.score([[1,2]])['event_confusion'],dict(tp=1,fn=0,fp=0,tn=1))
    def test_mixed_rejected(self): self.assertEqual(self.score([[1,3]])['unmatched_alerts'],[0])
    def test_duplicate_penalty(self): self.assertEqual(self.score([[1,2],[1,2]])['alert_precision'],.5)
    def test_benign_fp(self): self.assertEqual(self.score([[3,4]])['event_confusion']['fp'],1)
    def test_missing_packet(self): self.assertEqual(self.score([[1,99]])['unmatched_alerts'],[0])
    def test_threshold(self): self.assertEqual(self.score([[1]])['unmatched_alerts'],[0])
    def test_window(self): self.d[2]['time_ns']=100*10**9;self.assertEqual(self.score([[1,2]])['unmatched_alerts'],[0])
    def test_pair(self): self.d[2]['src']='other';self.assertEqual(self.score([[1,2]])['unmatched_alerts'],[0])
    def test_flags(self): self.d[2]['ack']=True;self.assertEqual(self.score([[1,2]])['unmatched_alerts'],[0])
if __name__=='__main__':unittest.main()
